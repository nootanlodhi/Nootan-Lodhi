package com.example.myfirstvollyjson;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b1;
    EditText txtCity;
    ImageView imageView;
    //Volley volley;
    ProgressDialog dialog;
    RequestQueue requestQueue;
    public  static final String IMAGE_URL="https://www.microsoft.com/en-us/p/weather-weather-forecast-live-weather-app/9nvkj68ql691?activetab=pivot:overviewtab";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        imageView=findViewById(R.id.imageView2);
        txtCity=findViewById(R.id.editTextTextPersonName);
        dialog=new ProgressDialog(this);
        b1.setOnClickListener(this);
        requestQueue=Volley.newRequestQueue(this);
    }

    @Override
    public void onClick(View v) {
        dialog.setMessage("Fetching data===========please wait");
        dialog.setCancelable(false);
        dialog.show();
        String cityName=txtCity.getText().toString();
        String JSON_URL="https://api.openweathermap.org/data/2.5/weather?appid=2a002d0daf75ac44e026293898434f2b&q="+cityName;
        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(JSON_URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    dialog.dismiss();
                    if(response.getString("cod").equals("404")){
                        AlertDialog.Builder builder1=new AlertDialog.Builder(MainActivity.this);
                        builder1.setMessage(response.getString("message"));
                        builder1.setTitle("Weather data");
                        builder1.show();
                        return;
                    }
                    JSONObject jsonObject = response.getJSONObject("main");
                    String dese = response.getJSONArray("weather").getJSONObject(0).getString("description");
                    double temp = jsonObject.getDouble("temp") - 273.0d;
                    double feels = jsonObject.getDouble("feels_like") - 273.0d;
                    double min=jsonObject.getDouble("temp_min")-273.0d;
                    double max=jsonObject.getDouble("temp_max")-273.0d;
                    int humadity = jsonObject.getInt("humidity");
                    StringBuilder builder = new StringBuilder();
                    builder.append("Temp is= " + temp + "\n");
                    builder.append("Feels_Like = " + feels + "\n");
                    builder.append("temp_min = "+min+"\n");
                    builder.append("temp_max is = "+max+"\n");
                    builder.append("humidity is = " + humadity + "\n");
                    builder.append("description is = " + dese + "\n");
                    builder.append("==============\n\n");
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
                    builder1.setMessage(builder.toString());
                    builder1.setTitle("Weather data");
                    builder1.setIcon(R.mipmap.weather_icon);
                    builder1.setCancelable(false);
                    builder1.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder1.show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Toast.makeText(MainActivity.this,"Error "+error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
          requestQueue.add(jsonObjectRequest);
    }

}